const buttons = document.querySelectorAll('.filtros button');
const categorias = document.querySelectorAll('.categoria');

buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    buttons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const filter = btn.getAttribute('data-filter');
    categorias.forEach(cat => {
      if (cat.classList.contains(filter)) {
        cat.classList.add('active');
      } else {
        cat.classList.remove('active');
      }
    });
  });
});